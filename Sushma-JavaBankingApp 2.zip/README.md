# 💳 Java CLI Banking App

This is a basic Java CLI project that simulates a simple bank account system.

## Features
- Deposit money
- Withdraw money with balance check
- Display current balance

## How to Run

```bash
javac BankAccount.java
java BankAccount
```