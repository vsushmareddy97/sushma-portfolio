# ☁️ Azure DevOps CI/CD Project

This project demonstrates how to build and run a Java app using an Azure DevOps pipeline.

## Files
- `azure-pipelines.yml`: CI/CD pipeline definition
- `BankAccount.java`: Simple demo Java program

## Pipeline Features
- Triggered on push to main
- Uses Java 11 on Ubuntu
- Builds and runs a Java CLI app