public class BankAccount {
    public static void main(String[] args) {
        System.out.println("Azure DevOps CI/CD Demo - Java App Running Successfully!");
    }
}